#pragma once
class Encryption
{
};

